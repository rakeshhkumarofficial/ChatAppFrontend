import { Component } from '@angular/core';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.componenet.html',
})
export class ContactUsComponent {

}
