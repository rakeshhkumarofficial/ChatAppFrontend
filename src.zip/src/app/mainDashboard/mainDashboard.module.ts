import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainRoutingModule } from './main-routing.module';
import { HomeComponent } from './Home/home.component';
import { AboutComponent } from './About/about.component';
import { FooterComponent } from './Footer/footer.component';
import { ContactUsComponent } from './Contact-us/contact.componenet';
import { HeaderComponent } from './Header/header.component';
import { SearchComponent } from './Search/search.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@microsoft/signalr';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [HomeComponent,AboutComponent,FooterComponent,ContactUsComponent,HeaderComponent,SearchComponent],
  imports: [
    CommonModule,
    MainRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  exports:[
   
  ]
  
})
export class MainDashboardModule { }
