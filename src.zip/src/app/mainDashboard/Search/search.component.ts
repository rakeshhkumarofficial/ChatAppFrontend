import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SocketconnectionService } from 'src/app/services/socket/socketconnection.service';
import { ChatServiceService } from '../services/chat-service.service';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent {
    allsearchUser:any=[]
    searchForm:FormGroup

    constructor(private userdata:ChatServiceService ,private fb:FormBuilder ,private hub:SocketconnectionService){
        this.searchForm = this.fb.group({
            name: ['', Validators.required],
          })

    }
    searchUser(){
        console.log(this.searchForm.value)
        this.userdata.searchUser(this.searchForm.value).subscribe((res:any)=>{
    this.allsearchUser=res.data;
    console.log(this.allsearchUser)
    })

    }
    startConnection(){
   this.hub.startConnection();
   setTimeout(() => {
  this.hub.invokeMethod("CreateChat","gpaswan1976@gmail.com")
   },2000)

    }

}
