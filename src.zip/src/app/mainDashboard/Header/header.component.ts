import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
})
export class HeaderComponent {
  constructor(private authdata :AuthService ,private routes:Router){
  }
  changePassword() {

  
  }
logOut() {
  this.authdata.logout();
  Swal.fire(
    'logout sucessfully',
    'you has been logout',
    'success'
  )
  
}

}
