import { Injectable } from '@angular/core';
import * as signalR from "@microsoft/signalr";
import { chatconnection } from 'src/constant';
import { HttpClient } from '@microsoft/signalr';
import { AnyCatcher } from 'rxjs/internal/AnyCatcher';
const token :any  = localStorage.getItem("token");
@Injectable({
  providedIn: 'root'
})
export class SocketconnectionService {
  
public socketConnection :signalR.HubConnection |any
  constructor() { }
  public startConnection(){
    this.socketConnection = new signalR.HubConnectionBuilder().withUrl(chatconnection,
      { 
          skipNegotiation: true,
           transport: signalR.HttpTransportType.WebSockets,
           accessTokenFactory :()=> token
      }).withAutomaticReconnect().build();

      this.socketConnection.start().then(()=>{
          console.log("Connection started ");
      }).catch((error: any)=>{
          console.log(" Error While starting connection "+error);
      });

      
  }

  invokeMethod(method:string, data:any) {
    this.socketConnection.send(method,data)
  }
}
